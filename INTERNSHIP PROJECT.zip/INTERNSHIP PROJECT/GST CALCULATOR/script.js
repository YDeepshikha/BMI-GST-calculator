function openDeveloperInfo() {
    window.open('http://vaibhavpathak.diagodevelopers.dx.am/', '_blank');
}

function calculateGST() {
    const amount = document.getElementById('amount').value;
    const gstPercent = document.getElementById('gst-percent').value;
    const resultDiv = document.getElementById('result');

    if (amount === "") {
        alert("GST Amount can't be blank");
        return;
    }

    const amountNumber = parseFloat(amount);

    if (isNaN(amountNumber)) {
        alert("Amounts are only in digits!");
        return;
    }

    if (amountNumber === 0) {
        alert("GST Amount can't be zero!");
        return;
    }

    const gstCharge = (amountNumber / 100) * parseInt(gstPercent);
    resultDiv.textContent = `Your GST Charge is ${gstCharge.toFixed(2)}`;
}
