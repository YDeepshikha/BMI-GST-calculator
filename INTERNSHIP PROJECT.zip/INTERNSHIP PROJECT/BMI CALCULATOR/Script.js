function calculateBMI() {
    var weight = parseFloat(document.getElementById('weight').value);
    var height = parseFloat(document.getElementById('height').value) / 100; // Convert height to meters
    
    if (isNaN(weight) || isNaN(height) || height === 0) {
        alert("Please enter valid values for weight and height.");
        return;
    }
    
    var bmi = weight / (height * height);
    var bmiCategory = getBMICategory(bmi);
    
    document.getElementById('bmiValue').textContent = bmi.toFixed(1);
    document.getElementById('bmiCategoryText').textContent = bmiCategory;
}

function getBMICategory(bmi) {
    if (bmi < 18.5) {
        return "Underweight";
    } else if (bmi >= 18.5 && bmi < 24.9) {
        return "Normal weight";
    } else if (bmi >= 25 && bmi < 29.9) {
        return "Overweight";
    } else {
        return "Obesity";
    }
}
